# Decrypt Chrome Passwords
A simple program to decrypt chrome password saved on your machine. <br>
This code has only been tested on windows, so it may not work on other OS.<br>
If you have an idea for improvement, do let me know!<br>

## OS support
1. Windows

## Dependencies (see requirements)
1. sqlite
2. pycryptodomex
3. pywin32

## Usage
python decrypt_chrome_password.py<br>

## Output
Saved as decrypted_password.csv

## Medium
To understand the how this program works, read my medium article. <br>
https://ohyicong.medium.com/how-to-hack-chrome-password-with-python-1bedc167be3d


